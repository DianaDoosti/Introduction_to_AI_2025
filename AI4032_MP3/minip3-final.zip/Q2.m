epsilon = 0.1;
[x1, x2] = meshgrid(-1:epsilon:1, -1:epsilon:1);
X = [x1(:), x2(:)];
Y = 1 ./ (3 + x1(:).^2 + x2(:).^2);
data = [X Y];

writematrix(data, 'anfis_data.dat');
