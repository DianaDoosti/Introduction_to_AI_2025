clc;
clear;
close all;

% Load the training data
load('diabetes_train.mat');  % loads variable 'data'
trainData = data;

% Load the test data
load('diabetes_test.mat');
testData = data;

% Separate inputs and output
trainX = trainData(:, 1:end-1);  % 8 features
trainY = trainData(:, end);     % binary target

testX = testData(:, 1:end-1);
testY = testData(:, end);

anfisTrainData = [trainX trainY];
anfisTestData = [testX testY];

% Generate FIS (genfis2 alternative)
opt = genfisOptions('SubtractiveClustering', 'ClusterInfluenceRange', 0.5);
initFIS = genfis(trainX, trainY, opt);

% Train ANFIS
numEpochs = 300;
trainedFIS = anfis([trainX trainY], initFIS, numEpochs);

% Evaluate (updated syntax and suppress warnings)
fisOptions = evalfisOptions("OutOfRangeInputValueMessage", "none");
output = evalfis(trainedFIS, testX, fisOptions);
predicted = double(output >= 0.45);

% Accuracy
accuracy = sum(predicted == testY) / length(testY);
fprintf('Test Accuracy: %.2f%%\n', accuracy * 100);

% Confusion Matrix
confMat = confusionmat(testY, predicted);
disp('Confusion Matrix:');
disp(confMat);

% Extract values from confusion matrix
TP = confMat(2,2); % True Positives
TN = confMat(1,1); % True Negatives
FP = confMat(1,2); % False Positives
FN = confMat(2,1); % False Negatives

% Calculate Sensitivity and Specificity
sensitivity = TP / (TP + FN);  % True Positive Rate
specificity = TN / (TN + FP);  % True Negative Rate

% Display the results
fprintf('Sensitivity (True Positive Rate): %.4f\n', sensitivity);
fprintf('Specificity (True Negative Rate): %.4f\n', specificity);

writeFIS(trainedFIS, 'Q7.fis');
