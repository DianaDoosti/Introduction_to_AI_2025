clc; clear; close all;

%% 1. تولید سری زمانی Mackey-Glass
N = 2000;              % طول سیگنال
beta = 0.2; gamma = 0.1; n = 10; tau = 25;
x = zeros(N,1);
x(1) = 1.2;

for t = 2:N
    if t - tau > 0
        x_tau = x(t - tau);
    else
        x_tau = 0;
    end
    x(t) = x(t-1) + (beta * x_tau / (1 + x_tau^n) - gamma * x(t-1));
end

%% 2. ساخت داده‌های ورودی–خروجی با تاخیر
delay = 2;
data = [];
for i = delay+1:N-1
    data = [data; x(i-delay:i)', x(i+1)];
end

input = data(:, 1:delay+1);  % [x(k-2), x(k-1), x(k)]
output = data(:, end);       % x(k+1)

%% 3. تقسیم داده به آموزش و تست
train_ratio = 0.8;
train_len = round(train_ratio * size(input,1));
train_input = input(1:train_len, :);
train_output = output(1:train_len);
test_input = input(train_len+1:end, :);
test_output = output(train_len+1:end);

%% 4. ساخت FIS اولیه و آموزش ANFIS
opt = genfisOptions('GridPartition');
opt.NumMembershipFunctions = 3;
opt.InputMembershipFunctionType = 'gaussmf';
initial_fis = genfis(train_input, train_output, opt);

anfis_opt = anfisOptions('InitialFIS', initial_fis, ...
                         'EpochNumber', 100, ...
                         'ValidationData', [test_input test_output]);

[fis_trained, trainError, ~, fis_info] = anfis([train_input train_output], anfis_opt);

%% 5. ارزیابی مدل
y_pred = evalfis(test_input, fis_trained);

figure;
plot(test_output, 'b', 'DisplayName', 'Real Output'); hold on;
plot(y_pred, 'r--', 'DisplayName', 'ANFIS Predicted');
legend; grid on;
xlabel('Sample');
ylabel('x(k+1)');
title('پیش‌بینی Mackey-Glass با ANFIS');

%% 6. خطای میانگین مربعات
mse = mean((test_output - y_pred).^2);
disp(['MSE: ', num2str(mse)]);

%% 7. نمایش توابع عضویت
figure;
for i = 1:size(input, 2)
    subplot(size(input,2), 1, i);
    plotmf(fis_trained, 'input', i);
    title(['Membership Functions for Input ', num2str(i)]);
end

%% 8. نمایش قوانین
figure;
ruleview(fis_trained);