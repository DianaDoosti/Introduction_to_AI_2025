clc; clear; close all;

% Common setup
domain = [-1 1];
centers = [-1 1];
N = 2;

%% === FIS 1: Trapezoidal MFs at Ends ===
fis_trap = sugfis('Name','Q5_trap');

% Add Inputs
fis_trap = addInput(fis_trap, domain, 'Name', 'x1');
fis_trap = addInput(fis_trap, domain, 'Name', 'x2');

% Trapezoidal MFs centered at ends
w = 0.6;  % width to control overlap

% x1 MFs
fis_trap = addMF(fis_trap, 'x1', 'trapmf', [-1 -1 -1+w -1+w+w], 'Name', 'Low');
fis_trap = addMF(fis_trap, 'x1', 'trapmf', [1-w-w 1-w 1 1], 'Name', 'High');

% x2 MFs
fis_trap = addMF(fis_trap, 'x2', 'trapmf', [-1 -1 -1+w -1+w+w], 'Name', 'Low');
fis_trap = addMF(fis_trap, 'x2', 'trapmf', [1-w-w 1-w 1 1], 'Name', 'High');

% Output
fis_trap = addOutput(fis_trap, [0 1], 'Name', 'y');

% Add constant MFs for output
for i = 1:N
    for j = 1:N
        idx = (i - 1) * N + j;
        fis_trap = addMF(fis_trap, 'y', 'constant', 1, 'Name', sprintf('Const_%d', idx));
    end
end

% Add rules
rules = [];
for i = 1:N
    for j = 1:N
        outIdx = (i - 1) * N + j;
        rules(end+1, :) = [i j outIdx 1 1]; %#ok<SAGROW>
    end
end

fis_trap = addRule(fis_trap, rules);
writeFIS(fis_trap, 'Q5_trap.fis');


%% === FIS 2: Triangular MFs at Ends ===
fis_tri = sugfis('Name','Q5_tri');

% Add Inputs
fis_tri = addInput(fis_tri, domain, 'Name', 'x1');
fis_tri = addInput(fis_tri, domain, 'Name', 'x2');

% Triangular MFs centered at ends
d = 1.2;  % controls width

% x1 MFs
fis_tri = addMF(fis_tri, 'x1', 'trimf', [-1 -1 -1+d], 'Name', 'Low');
fis_tri = addMF(fis_tri, 'x1', 'trimf', [1-d 1 1], 'Name', 'High');

% x2 MFs
fis_tri = addMF(fis_tri, 'x2', 'trimf', [-1 -1 -1+d], 'Name', 'Low');
fis_tri = addMF(fis_tri, 'x2', 'trimf', [1-d 1 1], 'Name', 'High');

% Output
fis_tri = addOutput(fis_tri, [0 1], 'Name', 'y');

% Add constant MFs
for i = 1:N
    for j = 1:N
        idx = (i - 1) * N + j;
        fis_tri = addMF(fis_tri, 'y', 'constant', 1, 'Name', sprintf('Const_%d', idx));
    end
end

% Add rules
rules = [];
for i = 1:N
    for j = 1:N
        outIdx = (i - 1) * N + j;
        rules(end+1, :) = [i j outIdx 1 1]; %#ok<SAGROW>
    end
end

fis_tri = addRule(fis_tri, rules);
writeFIS(fis_tri, 'Q5_tri.fis');


%% === Plot Approximations ===
[x1_grid, x2_grid] = meshgrid(linspace(-1,1,100), linspace(-1,1,100));
inputs = [x1_grid(:), x2_grid(:)];

% Evaluate fis_trap
y_trap = evalfis(fis_trap, inputs);
y_trap_grid = reshape(y_trap, size(x1_grid));

% Evaluate fis_tri
y_tri = evalfis(fis_tri, inputs);
y_tri_grid = reshape(y_tri, size(x1_grid));

% Plot Trapezoidal FIS Approximation
figure;
surf(x1_grid, x2_grid, y_trap_grid);
xlabel('x_1'); ylabel('x_2'); zlabel('Output');
title('Approximation Using Trapezoidal MFs');
shading interp; colormap turbo;

% Plot Triangular FIS Approximation
figure;
surf(x1_grid, x2_grid, y_tri_grid);
xlabel('x_1'); ylabel('x_2'); zlabel('Output');
title('Approximation Using Triangular MFs');
shading interp; colormap parula;
