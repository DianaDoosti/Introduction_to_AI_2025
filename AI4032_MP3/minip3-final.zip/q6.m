clc; clear; close all;

%% موقعیت اولیه و هدف
x = 0; y = 0; theta = 0;
xg = 2; yg = 2; thetag = pi/2;

dt = 0.1;                % گام شبیه‌سازی (ثابت می‌مونه)
max_steps = 1000;        % محدودیت برای جلوگیری از حلقه بی‌نهایت
goal_threshold = 0.0;   % آستانه رسیدن به هدف (متر)

% مسیرها
x_traj = [];
y_traj = [];
theta_traj = [];

%% سیستم فازی
fis = mamfis('Name', 'RobotController');

% ورودی فاصله
fis = addInput(fis, [0 3], 'Name', 'Distance');
fis = addMF(fis, 'Distance', 'trapmf', [0 0 0.5 1], 'Name', 'Close');
fis = addMF(fis, 'Distance', 'trimf', [0.5 1.5 2.5], 'Name', 'Medium');
fis = addMF(fis, 'Distance', 'trapmf', [2 2.5 3 3], 'Name', 'Far');

% ورودی زاویه
fis = addInput(fis, [-pi pi], 'Name', 'Angle');
fis = addMF(fis, 'Angle', 'trimf', [-pi -pi/2 0], 'Name', 'Left');
fis = addMF(fis, 'Angle', 'trimf', [-0.5 0 pi/2], 'Name', 'Zero');
fis = addMF(fis, 'Angle', 'trimf', [0 pi/2 pi], 'Name', 'Right');

% خروجی سرعت خطی v
fis = addOutput(fis, [0 0.5], 'Name', 'v');
fis = addMF(fis, 'v', 'trimf', [0 0 0.2], 'Name', 'Slow');
fis = addMF(fis, 'v', 'trimf', [0.1 0.25 0.4], 'Name', 'Medium');
fis = addMF(fis, 'v', 'trimf', [0.3 0.5 0.5], 'Name', 'Fast');

% خروجی سرعت زاویه‌ای w
fis = addOutput(fis, [-1 1], 'Name', 'w');
fis = addMF(fis, 'w', 'trimf', [-1 -1 0], 'Name', 'TurnLeft');
fis = addMF(fis, 'w', 'trimf', [-0.5 0 0.5], 'Name', 'NoTurn');
fis = addMF(fis, 'w', 'trimf', [0 1 1], 'Name', 'TurnRight');

% قوانین فازی
ruleList = [
    1 1 1 1 1 1;
    1 2 2 2 1 1;
    1 3 2 3 1 1;
    2 1 1 1 1 1;
    2 2 2 2 1 1;
    2 3 2 3 1 1;
    3 1 2 1 1 1;
    3 2 3 2 1 1;
    3 3 3 3 1 1;
];
fis = addRule(fis, ruleList);

%% شبیه‌سازی تا رسیدن به هدف
step = 1;
while step <= max_steps
    dx = xg - x;
    dy = yg - y;
    d = sqrt(dx^2 + dy^2);             % فاصله تا هدف
    
    if d < goal_threshold
        disp(['ربات به هدف رسید در ', num2str(step), ' گام.']);
        break;
    end

    alpha = atan2(dy, dx) - theta;     % اختلاف زاویه
    alpha = atan2(sin(alpha), cos(alpha));  % نرمال‌سازی

    % خروجی سیستم فازی
    input = [d alpha];
    output = evalfis(fis, input);
    v = min(max(output(1), 0), 0.5);
    w = min(max(output(2), -1), 1);

    % به‌روزرسانی وضعیت ربات
    x = x + v * cos(theta);
    y = y + v * sin(theta);
    theta = theta + w;

    % ذخیره مسیر
    x_traj(end+1) = x;
    y_traj(end+1) = y;
    theta_traj(end+1) = theta;

    step = step + 1;
end

%% نمایش مسیر
figure;
plot(x_traj, y_traj, 'b-', 'LineWidth', 2); hold on;
plot(xg, yg, 'ro', 'MarkerFaceColor', 'r');
xlabel('X'); ylabel('Y');
title('مسیر حرکت ربات تا رسیدن به هدف');
axis equal; grid on;
legend('مسیر ربات', 'هدف');