clc; clear; close all

N      = 300;
x_all  = linspace(-1,1,N)';
y_all  = exp(-pi*x_all.^2) + x_all.*sin(pi*x_all);

perm   = randperm(N);
nTr    = round(0.8*N);
trnX   = x_all(perm(1:nTr));
trnY   = y_all(perm(1:nTr));
tstX   = x_all(perm(nTr+1:end));
tstY   = y_all(perm(nTr+1:end));

nMF   = 5;         
fis0  = genfis1([trnX trnY], nMF, 'gaussmf');

opt = anfisOptions( ...
    'InitialFIS',        fis0, ...
    'EpochNumber',       50, ...      % تعداد تکرارها
    'OptimizationMethod',1, ...       % 1 = pure gradient descent
    'DisplayANFISInformation', 0, ...
    'DisplayErrorValues',      0      ...
);

[fisGD, trainErr] = anfis([trnX trnY], opt);

y_pred = evalfis(fisGD, tstX);
maxErr = max(abs(y_pred - tstY));
rmse   = sqrt(mean((y_pred - tstY).^2));

fprintf('پس از گرادیان نزولی:\n');
fprintf('  تعداد قوانین: %d\n', length(fisGD.Rules));
fprintf('  خطای ماکزیمم: %.4f\n', maxErr);
fprintf('  RMSE:          %.4f\n', rmse);

xx = linspace(-1,1,200)';
yy = exp(-pi*xx.^2) + xx.*sin(pi*xx);
zz = evalfis(fisGD, xx);

figure
plot(xx, yy, 'b-', 'LineWidth',1.5), hold on
plot(xx, zz, 'r--','LineWidth',1.5)
legend('trained model','actual')
xlabel('x'), ylabel('h(x)'), grid on
title('مقایسه تقریب')