clc; clearvars; close all

nodes = [ 1.0000, 0.8571, 0.7142, 0.5714, 0.4285, 0.2857, 0.1428, 0, ...
         -0.1428, -0.2857, -0.4285, -0.5714, -0.7142, -0.8571, -1.0000 ];
fcnVals = exp(-pi*nodes.^2) + nodes .* sin(pi*nodes);
for k = 1:numel(nodes)
    fprintf('MF%02d @ %+6.4f: %.4f\n', k, nodes(k), fcnVals(k));
end

samplePts = linspace(-1, 1, 300)';
exactVals = exp(-pi*samplePts.^2) + samplePts .* sin(pi*samplePts);
fuzzySys = readfis('sugenotype1.fis');
approxVals = evalfis(fuzzySys, samplePts);

figure
plot(samplePts, exactVals, 'LineWidth', 2), hold on
plot(samplePts, approxVals, '--', 'LineWidth', 2)
legend('Exact','Fuzzy'), xlabel('x'), ylabel('f(x)'), title('Exact vs Fuzzy'), grid on

rmseErr = sqrt(mean((exactValmis - approxVals).^2));
maxErr  = max(abs(exactVals - approxVals));
fprintf('RMSE:     %.6f\nMaxErr:   %.6f\n', rmseErr, maxErr);